import React from 'react'
import { Row, Col, Navbar, NavItem } from 'react-materialize';


class Layout extends React.Component {
  render () {
    return(
      <Row>
        <Col s={12}>
        <Navbar brand='Used Cars App' left>
        <NavItem href='#/'>Home</NavItem>
        <NavItem href='#/add'>Add</NavItem>
        </Navbar>
        {this.props.children}
        </Col>
      </Row>
    );

  }
}

export default Layout;
